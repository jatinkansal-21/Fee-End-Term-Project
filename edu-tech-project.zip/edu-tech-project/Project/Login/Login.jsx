import React, { useState } from 'react';
import login_image from '../../images/login-image.png';
const Login = () => {
    const [formData, setFormData] = useState({
        username: '',
        password: ''
    });

    const [result, setResult] = React.useState("");

    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setFormData({
            ...formData,
            [name]: value
        });
    }

    const handleSubmit = async (event) => {
        event.preventDefault();
        setResult("Sending....");
        const formData = new FormData(event.target);
    
        formData.append("access_key", 
        "03aab3b9-928d-4dfe-951d-026db2a6298b");
    
        const response = await fetch("https://api.web3forms.com/submit", {
          method: "POST",
          body: formData
        });
    
        const data = await response.json();
    
        if (data.success) {
          setResult("Form Submitted Successfully");
          event.target.reset();
        } else {
          console.log("Error", data);
          setResult(data.message);
        }
      };  

    return (
        <div style={styles.container} className='login'>
            <div style={styles.left}>
                <h2>Welcome Back!</h2>
                <form onSubmit={handleSubmit}>
                    <div style={styles.formGroup}>
                        <label htmlFor="username" style={styles.label}>Username:</label>
                        <input 
                            type="text" 
                            id="username" 
                            name="username" 
                            value={formData.username} 
                            onChange={handleInputChange} 
                            style={styles.input}
                        />
                    </div>
                    <div style={styles.formGroup}>
                        <label htmlFor="password" style={styles.label}>Password:</label>
                        <input 
                            type="password" 
                            id="password" 
                            name="password" 
                            value={formData.password} 
                            onChange={handleInputChange} 
                            style={styles.input}
                        />
                    </div>
                    <button type="submit" style={styles.button}>Login</button>
                    <div>{result}</div>
                </form>

            </div>
            <div style={styles.right}>
                {/* todo: update the src for this img */}
                <img src={login_image} alt="Login" style={styles.img} />
            </div>
        </div>
    );
}

const styles = {
    container: {
        margin: '100px auto',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        width: '90%',
    },
    left: {
        flexBasis: '40%',
        maxWidth: '400px',
    },
    right: {
        flexBasis: '56%',
    },
    img: {
        width: '100%',
        borderRadius: '10px',
    },
    formGroup: {
        marginBottom: '20px',
    },
    label: {
        fontSize: '16px',
        color: '#212EA0',
        marginBottom: '5px',
    },
    input: {
        width: '100%',
        padding: '8px',
        marginBottom: '10px',
        border: '1px solid #ccc',
        borderRadius: '5px',
        boxSizing: 'border-box',
    },
    button: {
        width: '100%',
        padding: '10px',
        backgroundColor: '#212EA0',
        color: '#fff',
        border: 'none',
        borderRadius: '5px',
        cursor: 'pointer',
    },
    // Add more styles as needed
};

export default Login;
