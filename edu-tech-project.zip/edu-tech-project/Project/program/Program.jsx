import React from 'react';
import './Program.css';

const Program = () => {

  const data = [
    {
      imageUrl : "https://i.ytimg.com/vi/KRc5YCjr0_M/maxresdefault.jpg",
      title: "C++ Course",
      youtubeLink: "https://www.youtube.com/watch?v=WQoB2z67hvY&list=PLDzeHZWIZsTryvtXdMr6rPh4IDexB5NIA&index=2"
    },
    {
      imageUrl : "https://static.skillshare.com/uploads/video/thumbnails/3a61a8763d9357228f649d422603760b/original",
      title: "Java Course",
      youtubeLink: "https://youtu.be/yRpLlJmRo2w?si=bwfukle7FnpIimFt"
    },
    {
      imageUrl : "https://img.graphicsurf.com/2020/06/Web-development-courses-flat-design-720x480.jpg",
      title: "WebDev Course",
      youtubeLink: "https://youtu.be/l1EssrLxt7E?si=gyWcu58X4pM4YCQM"
    }
  ]
 
  return (
    <div className='card_container'>
      {data.map((card) => <Card imageUrl={card.imageUrl} title={card.title} youtubeLink={card.youtubeLink}/>)}
      
    </div>
  );
};

export default Program;


const Card = ({ imageUrl, title, youtubeLink }) => {
  const handleClick = () => {
    window.open(youtubeLink, '_blank');
  };

  return (
    <div className="card" onClick={handleClick} style={{ backgroundImage: `url(${imageUrl})` }}>
      <h2 className="card-title">{title}</h2>
    </div>
  );
};