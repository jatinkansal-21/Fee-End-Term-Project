import React from 'react'
import './About.css'

import about_img from '../../images/about.png'
import play_icon from '../../images/play-icon.png'

const About = ({setPlayState}) => {
  return (
    <div className='about'>
      <div className="about-left">
        <img src={about_img} alt="" className='about-img'/>
        <img src={play_icon} alt="" className='play-icon' onClick={()=>{setPlayState(true)}}/>
      </div>

      <div className="about-right">
        <h3>ABOUT UNIVERSITY</h3>
        <h2>Nurturing Tomorrow's Leaders Today</h2>
        <p>Elevate your learning experience with our cutting-edge courses. From beginner to expert, our platform offers something for everyone. Start learning today and reach new heights!</p>

        <p>Discover the power of personalized learning with our platform. Our adaptive approach ensures you learn at your pace, anytime, anywhere. Start your journey to success today!</p>

        <p>Join the future of education with our revolutionary platform. Experience interactive learning like never before, and unlock your full potential. Your journey to mastery starts here!</p>
      </div>
    </div>
  )
}
export default About