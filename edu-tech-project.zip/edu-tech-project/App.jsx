// import logo from './logo.svg';
// import './App.css';
// import Item from './components/Item'
// import ItemDate from './components/ItemDate'; 
// import Card from './components/Card';

// function App(){
//   const response = [
//     {
//       itemName:"Nirma",
//       itemDate:"20",
//       itemMonth:"June",
//       itemYear:"2004"
//     },
//     {
//       itemName:"Nirma2",
//       itemDate:"202",
//       itemMonth:"June2",
//       itemYear:"20042"
//     },
//     {
//       itemName:"Nirma3",
//       itemDate:"203",
//       itemMonth:"June3",
//       itemYear:"20043"
//     }
// ]
//   return (
//     <div>
//       <Card>

//       <Item name={response[0].itemName}>Hello jee aap kaise ho?</Item>
//       <ItemDate day={response[0].itemDate} month={response[0].itemMonth} year={response[0].itemYear}></ItemDate>

//       <Item name={response[1].itemName}></Item>
//       <ItemDate day={response[1].itemDate} month={response[1].itemMonth} year={response[1].itemYear}></ItemDate>

//       <Item name={response[2].itemName}></Item>
//       <ItemDate day={response[2].itemDate} month={response[2].itemMonth} year={response[2].itemYear}></ItemDate>

//       <div className="App">Hello jee</div>
//       </Card>
//     </div>
//   );
// }
// export default App;





// import React from 'react';
// import Products from './components/Products';
// import NewProduct from './components/NewProduct';

// const App = ()  => {
//   const products =[
//     {
//       id:'p1',
//       title:'Nirma',
//       amount:100,
//       date:new Date(2021,8,10),
//     },
//     {
//       id:'p2',
//       title:'Surf-Excel',
//       amount:150,
//       date:new Date(2021,2,12),
//     },
//     {
//       id:'p3',
//       title:'Tide',
//       amount:200,
//       date:new Date(2011,1,13),
//     },
//     {
//       id:'p4',
//       title:'Mr.White',
//       amount:300,
//       date:new Date(2010,6,30),
//     },
//   ];

//   return (
//     <div>
//       <NewProduct />
//       <Products items={products}/>
//     </div>
//   );
// }

// export default App;



// import React from 'react';
// import Proj from './components/Project';

// const App = () => {
//   return (
//     <Proj/>
//   )
// }

// export default App;



// Project starts here

import React from 'react';
import { Route, Routes } from 'react-router-dom';
import Home from './Home';
import { HomeChild } from './Home';
import Program from './program/Program';


const App = () => {

 
  return (
    <Routes>
      <Route path='/' element= {<Home/>}>
        <Route path='/' element={<HomeChild/>}/>
      <Route path='/program' element={<Program/>}/>
      </Route>
    
    </Routes>
  )
}

export default App