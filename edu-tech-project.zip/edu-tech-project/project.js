// import React from 'react';

// const Proj = () => {
//   return (
//     <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', backgroundColor: '#f0f0f0' }}>
//       <div style={{ position: 'absolute', top: '20px', left: '20px', display: 'flex', flexDirection: 'column' }}>
//         <button style={{ marginBottom: '10px' }}>Home</button>
//         <button style={{ marginBottom: '10px' }}>About</button>
//         <button>Services</button>
//       </div>
//       <img src="https://via.placeholder.com/150" alt="placeholder" />
//     </div>
//   );
// };

// export default Proj;
