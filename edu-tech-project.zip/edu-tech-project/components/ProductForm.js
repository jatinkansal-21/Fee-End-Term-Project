import {useState} from 'react';
import './ProductForm.css';

function ProductForm(){

    const [title, setTitle] = useState('');
    const [date, setDate] = useState('');


    function titleChangeHandler(event){
        setTitle(event.target.value);
        console.log(event.target.value);
    }

    function dateChangeHandler(event){
        setDate(event.target.value);
        console.log(event.target.value);
        // console.log(date);
        // console.log(title);
    }
    return (
        <form>
            <div className='new-product-controls'>
                <div className='new-product-control'>
                    <label>Title</label>
                    <input type="text" onChange={titleChangeHandler}></input>
                </div>

                <div className='new-product-control'>
                    <label>Date</label>
                    <input type="date" onChange={dateChangeHandler}></input>
                </div>

                <div className='new-product-control'>
                    <button type="submit">Add Product</button>
                </div>

            </div>
        </form>
    );
}

export default ProductForm;