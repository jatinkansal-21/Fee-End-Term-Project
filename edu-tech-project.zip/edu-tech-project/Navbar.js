import React from 'react'
// import PropTypes from 'prop-types'


function Navbar(props) {
  return (
    <>
    <div>
    <h1>hello world {props.hello}</h1>
      
    </div>
    </>
  )
}

export default Navbar

