import React, { useState } from 'react'
import Navbar from './Project/Navbar/Navbar'
import Hero from './Project/Hero/Hero'
import Programs from './Project/Programs/Programs'
import Title from './Project/Title/Title'
import About from './Project/About/About'
import Campus from './Project/Campus/Campus'
import Testimonials from './Project/Testimonials/Testimonials'
import Contact from './Project/Contact/Contact'
import Footer from './Project/Footer/Footer'
import VideoPlayer from './Project/VideoPlayer/VideoPlayer'
import Login from './Project/Login/Login';
import { Outlet } from 'react-router-dom'
function Home() {

  return (
    <div>
      <div>
      <Navbar/>
      {<Outlet/>}
      <Login/>
    </div>
    </div>
  )
}

export default Home

export function HomeChild() {
    const [playState, setPlayState] = useState(false);
    return (
        <>
        <Hero/>
      <div className="container">
      <Title subTitle='Our PROGRAM' title='What We Offer'/>
      <Programs/>
      <About setPlayState={setPlayState}/>
      <Title subTitle='Gallery' title='Campus Photos'/>
      <Campus/>
      <Title subTitle='TESTIMONIALS' title='What Students Says'/>
      <Testimonials/>
      <Title subTitle='Contact Us' title='Get in Touch'/>
      <Contact/>
      <Footer/>
      </div>
      <VideoPlayer playState={playState} setPlayState={setPlayState}/>
      <div>
      </div>
      </>
    )
}